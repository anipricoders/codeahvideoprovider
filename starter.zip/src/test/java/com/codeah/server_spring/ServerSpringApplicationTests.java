package com.codeah.server_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
